// Variables para el carrito
const cartItems = {};
const cartTable = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");

// Función para agregar un producto al carrito
function addToCart(product, price) {
    if (!cartItems[product]) {
        cartItems[product] = { price: parseFloat(price), quantity: 1 };
    } else {
        cartItems[product].quantity++;
    }
    updateCart();
}

// Función para eliminar un producto del carrito
function removeFromCart(product) {
    if (cartItems[product]) {
        if (cartItems[product].quantity > 1) {
            cartItems[product].quantity--;
        } else {
            delete cartItems[product];
        }
        updateCart();
    }
}

// Función para actualizar la tabla del carrito
function updateCart() {
    cartTable.innerHTML = "";
    let total = 0;

    for (const [product, details] of Object.entries(cartItems)) {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${product}</td>
            <td>$${details.price.toLocaleString()}</td>
            <td>${details.quantity}</td>
            <td>$${(details.price * details.quantity).toLocaleString()}</td>
            <td><button class="remove-from-cart" data-product="${product}">Eliminar</button></td>
        `;
        cartTable.appendChild(row);

        total += details.price * details.quantity;
    }

    cartTotal.textContent = `Total: $${total.toLocaleString()}`;
    setupRemoveButtons();
}

// Configura los botones de "Eliminar" después de cada actualización
function setupRemoveButtons() {
    const removeButtons = document.querySelectorAll(".remove-from-cart");
    removeButtons.forEach(button =>
        button.addEventListener("click", () => removeFromCart(button.dataset.product))
    );
}

// Configura los botones de "Agregar"
const addButtons = document.querySelectorAll(".add-to-cart");
addButtons.forEach(button =>
    button.addEventListener("click", () =>
        addToCart(button.dataset.product, button.dataset.price)
    )
);
