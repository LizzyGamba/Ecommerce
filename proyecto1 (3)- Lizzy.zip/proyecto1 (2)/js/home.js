const btnlogin = document.getElementById("btnlogin");
const url_products = "http://127.0.0.1:5502/products";

document.addEventListener("DOMContentLoaded", function(){
    cargar_productos(); //cargar productos
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if(isLoggedIn === "true"){
        btnlogin.textContent = "Cerrar Sesión";
    }else{
        btnlogin.textContent = "Iniciar Sesión";
    }
});

btnlogin.addEventListener("click", function(){
    if(btnlogin.textContent== "Cerrar Sesión"){
        localStorage.removeItem("isLoggedIn");
        localStorage.setItem("isLoggedIn", "false");
    }
});

async function cargar_productos() {
    try{
        const respuesta = await fetch(url_products,{
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (respuesta) {
            const productos = await respuesta.json();
            const ultimosProductos = productos.slice(-5).reverse();
            console.log(productos)
            productList = document.getElementById("product-list")

            // Recorrer cada producto y agregarlo al HTML
            ultimosProductos.forEach(producto => {
                // Crear el contenedor de cada producto
                const productItem = document.createElement("div");
                productItem.classList.add("product-item");

                // Crear y añadir la imagen
                const img = document.createElement("img");
                img.src = "./img/"+producto.image; // En producción, asegúrate de usar el path completo si es necesario
                img.alt = producto.name;
                productItem.appendChild(img);

                // Crear y añadir el nombre del producto
                const productName = document.createElement("h3");
                productName.textContent = producto.name;
                productItem.appendChild(productName);

                // Crear y añadir el precio
                const price = document.createElement("p");
                price.textContent = `$${producto.price}`;
                productItem.appendChild(price);

                // Crear y añadir el botón de compra
                const button = document.createElement("button");
                button.classList.add("btn-primary");
                button.textContent = "Comprar";
                productItem.appendChild(button);

                // Agregar el producto a la lista
                productList.appendChild(productItem);

            });
        }


    }catch(error){
        console.error(error);
    }
}