from flask import Flask, request, jsonify  # Importa Flask para crear la API y manejar solicitudes y respuestas JSON    
import mysql.connector  # Importa mysql.connector para conectarse a la base de datos MySQL
##INSTALAR FLASK-CORS
from flask_cors import CORS
app = Flask(__name__)  # Crea una instancia de Flask, que será nuestra aplicación web/API
CORS(app)

# Configuración de la conexión a la base de datos MySQL
db = mysql.connector.connect(
    host="localhost",
    user="root",  # Usuario de MySQL (cambiar según tus configuraciones)
    password="",  # Contraseña de MySQL (cambiar según tus configuraciones)
    database="ecommerce"  # Nombre de la base de datos MySQL
)

cursor = db.cursor(dictionary=True)  # Crea un cursor para interactuar con la base de datos y obtener resultados como diccionarios

#login
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    print("Email recibido:", email)
    print("Password recibido:", password)

    if not email or not password:
        return jsonify({'message': 'Faltan datos del usuario'}), 400

    # Ejecuta la consulta para buscar el usuario
    cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, password))
    user = cursor.fetchone()

    # Imprime el resultado de la consulta para depuración
    print("Resultado de la consulta:", user)

    if user:
        return jsonify({'message': 'Inicio de sesión exitoso', 'user': user}), 200
    else:
        return jsonify({'message': 'Credenciales incorrectas'}), 401



@app.route('/products', methods=['POST'])
def add_product():
    data = request.json
    name = data.get('name')
    price = data.get('price')
    stock = data.get('stock')

    print("Datos del producto recibidos:", data)

    if not name or not price or not stock:
        return jsonify({'message': 'Faltan datos del producto'}), 400

    # Ejecuta la consulta para agregar el producto
    cursor.execute("INSERT INTO products (name, price, stock) VALUES (%s, %s, %s)", (name, price, stock))
    db.commit()

    print("Producto añadido con éxito")
    return jsonify({'message': 'Producto añadido exitosamente'}), 201

@app.route('/products', methods=['GET'])
def get_products():
    # Consulta para obtener todos los productos
    cursor.execute("SELECT * FROM products")
    products = cursor.fetchall()

    print("Productos obtenidos:", products)
    return jsonify({'products': products}), 200


@app.route('/orders', methods=['POST'])
def create_order():
    data = request.json
    customer_id = data.get('customer_id')
    product_id = data.get('product_id')
    quantity = data.get('quantity')

    print("Datos de la orden recibidos:", data)

    if not customer_id or not product_id or not quantity:
        return jsonify({'message': 'Faltan datos de la orden'}), 400

    # Consulta para verificar stock del producto
    cursor.execute("SELECT stock FROM products WHERE id = %s", (product_id,))
    product = cursor.fetchone()

    if not product or product['stock'] < quantity:
        return jsonify({'message': 'Stock insuficiente o producto no encontrado'}), 400

    # Crear la orden
    cursor.execute(
        "INSERT INTO orders (customer_id, product_id, quantity) VALUES (%s, %s, %s)", 
        (customer_id, product_id, quantity)
    )
    # Actualizar el stock del producto
    cursor.execute(
        "UPDATE products SET stock = stock - %s WHERE id = %s", 
        (quantity, product_id)
    )
    db.commit()

    print("Orden creada con éxito")
    return jsonify({'message': 'Orden creada exitosamente'}), 201

@app.route('/orders', methods=['GET'])
def get_orders():
    # Consulta para obtener todas las órdenes
    cursor.execute("SELECT * FROM orders")
    orders = cursor.fetchall()

    print("Órdenes obtenidas:", orders)
    return jsonify({'orders': orders}), 200

@app.route('/login/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    # Verificar si el usuario existe
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()

    if not user:
        return jsonify({'message': 'Usuario no encontrado'}), 404

    # Eliminar el usuario
    cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
    db.commit()

    print(f"Usuario con ID {user_id} eliminado.")
    return jsonify({'message': 'Usuario eliminado exitosamente'}), 200

@app.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    # Verificar si el producto existe
    cursor.execute("SELECT * FROM products WHERE id = %s", (product_id,))
    product = cursor.fetchone()

    if not product:
        return jsonify({'message': 'Producto no encontrado'}), 404

    # Eliminar el producto
    cursor.execute("DELETE FROM products WHERE id = %s", (product_id,))
    db.commit()

    print(f"Producto con ID {product_id} eliminado.")
    return jsonify({'message': 'Producto eliminado exitosamente'}), 200

@app.route('/orders/<int:order_id>', methods=['DELETE'])
def delete_order(order_id):
    # Verificar si la orden existe
    cursor.execute("SELECT * FROM orders WHERE id = %s", (order_id,))
    order = cursor.fetchone()

    if not order:
        return jsonify({'message': 'Orden no encontrada'}), 404

    # Eliminar la orden
    cursor.execute("DELETE FROM orders WHERE id = %s", (order_id,))
    db.commit()

    print(f"Orden con ID {order_id} eliminada.")
    return jsonify({'message': 'Orden eliminada exitosamente'}), 200


# Ejecutar la API
if __name__ == '__main__':
    # cmd = open('C:\Users\Eliza\Downloads\proyecto1 (2)\proyecto1\SQL\SQL\scriptBD.sql')
    # db.execute(cmd)
    app.run(debug=True)  # Ejecuta la aplicación Flask en modo de depuración
